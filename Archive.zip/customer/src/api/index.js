
module.exports = {
    customer: require('./customer'),
    appEvent: require('./app-events')
}
