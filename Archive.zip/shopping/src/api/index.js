const appEvents = require('./app-events');

module.exports = {
    shopping: require('./shopping'),
    appEvents: require('./app-events')
}
